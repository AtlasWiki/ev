// ex: [1, { xp: 0, totalXP: 0, reward: ''} ]
const clubLvlsArray = Object.entries(clubLvls);
const sectionItems = Object.entries(sections)
const descriptionItems = Object.entries(descriptions)
