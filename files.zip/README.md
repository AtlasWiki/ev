This is a web app hosted for an online Eatventure calculator. Hosted in https://ev-calc-nu.vercel.app/

## Installation:

Locally download the files (or files.zip) and open the HTML file to use this calculator in case of the server going down.

<br>

1.) If you choose to not `git clone` nor download the files individually, you can download the files.zip and unzip it. 


<br>
<br>

Clone the repo (SKIP if doing step 1):

```git clone https://github.com/AtlasWiki/ev.git```

<br>

Open the HTML file and enjoy.

