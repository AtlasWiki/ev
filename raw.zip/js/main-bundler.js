const modules = [tabs, calculations, constants, changelogs, utilities, props]; 
modules.forEach(module => {
    Object.keys(module).forEach(key => {
        window[key] = module[key];
    });
});